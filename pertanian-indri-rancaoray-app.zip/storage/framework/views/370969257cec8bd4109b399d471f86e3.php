<!DOCTYPE html>
<html>
<head>
    <title>Laporan Operasional</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
        th, td { border: 1px solid black; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
    </style>
</head>
<body onload="window.print()"> <h2 style="text-align: center;">LAPORAN OPERASIONAL TANI RANCAORAY</h2>
    <p style="text-align: center;">Periode: <?php echo e($start); ?> s/d <?php echo e($end); ?></p>
    <hr>

    <h3>1. Ringkasan Eksekutif</h3>
    <table>
        <tr>
            <th>Total Pengeluaran</th>
            <th>Total Pemasukan</th>
            <th>Total Panen</th>
        </tr>
        <tr>
            <td>Rp<?php echo e(number_format($summary['total_expense'], 0, ',', '.')); ?></td>
            <td>Rp<?php echo e(number_format($summary['total_revenue'], 0, ',', '.')); ?></td>
            <td><?php echo e($summary['total_harvest']); ?> Kg</td>
        </tr>
    </table>

    <h3>2. Detail Pengeluaran (Pembiayaan Disetujui)</h3>
    <table>
        <tr>
            <th>Tanggal</th>
            <th>Status</th>
            <th>Nominal</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($p->submission_date); ?></td>
            <td><?php echo e($p->validation_status); ?></td>
            <td>Rp<?php echo e(number_format($p->total_cost, 0, ',', '.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="3" style="text-align:center;">Tidak ada data pembiayaan.</td></tr>
        <?php endif; ?>
    </table>

    <h3>3. Detail Pemasukan (Pesanan Selesai)</h3>
    <table>
        <tr>
            <th>Tanggal</th>
            <th>Metode Bayar</th>
            <th>Nominal</th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td><?php echo e($o->transaction_date); ?></td>
            <td><?php echo e($o->payment_method); ?></td>
            <td>Rp<?php echo e(number_format($o->total_payment, 0, ',', '.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="3" style="text-align:center;">Tidak ada data penjualan.</td></tr>
        <?php endif; ?>
    </table>

</body>
</html><?php /**PATH C:\laragon\www\skripsi-app-10522041\resources\views/reports/print.blade.php ENDPATH**/ ?>