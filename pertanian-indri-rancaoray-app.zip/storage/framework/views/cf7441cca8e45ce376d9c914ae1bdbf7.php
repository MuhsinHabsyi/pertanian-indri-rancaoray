<?php $__env->startSection('title', 'Tanam & Pupuk (Penggunaan Stok)'); ?>

<?php $__env->startSection('content'); ?>
<div class="space-y-6">

    <!-- Top Stock Information Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <!-- Stok Bibit Card -->
        <div class="bg-white border border-gray-200 rounded-xl p-5 shadow-sm space-y-3">
            <div class="flex items-center space-x-3">
                <div>
                    <h4 class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Stok Bibit Tersedia</h4>
                    <span class="text-lg font-bold text-gray-900">
                        <?php echo e(number_format($seeds->sum('stock_available'))); ?> <span class="text-xs font-normal text-gray-500">Unit/Kg</span>
                    </span>
                </div>
            </div>
            <div class="border-t border-gray-100 pt-2.5 space-y-1.5 text-xs text-gray-600">
                <?php $__empty_1 = true; $__currentLoopData = $seeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex justify-between items-center">
                        <span class="truncate font-medium text-gray-700"><?php echo e($s->name); ?></span>
                        <span class="font-bold text-emerald-700 ml-2 shrink-0"><?php echo e(number_format($s->stock_available)); ?> <?php echo e($s->unit); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span class="text-gray-400 italic">Belum ada stok bibit</span>
                <?php endif; ?>
            </div>
        </div>

        <!-- Stok Pupuk Card -->
        <div class="bg-white border border-gray-200 rounded-xl p-5 shadow-sm space-y-3">
            <div class="flex items-center space-x-3">
                <div>
                    <h4 class="text-xs font-semibold text-gray-500 uppercase tracking-wider">Stok Pupuk Tersedia</h4>
                    <span class="text-lg font-bold text-gray-900">
                        <?php echo e(number_format($fertilizers->sum('stock_available'))); ?> <span class="text-xs font-normal text-gray-500">Unit/Kg</span>
                    </span>
                </div>
            </div>
            <div class="border-t border-gray-100 pt-2.5 space-y-1.5 text-xs text-gray-600">
                <?php $__empty_1 = true; $__currentLoopData = $fertilizers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="flex justify-between items-center">
                        <span class="truncate font-medium text-gray-700"><?php echo e($f->name); ?></span>
                        <span class="font-bold text-blue-700 ml-2 shrink-0"><?php echo e(number_format($f->stock_available)); ?> <?php echo e($f->unit); ?></span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <span class="text-gray-400 italic">Belum ada stok pupuk</span>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Main Content Grid -->
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">

    <!-- Card 1: Mulai Penanaman / Tanam Bibit Baru -->
    <div class="bg-white border border-gray-200 rounded-lg p-6 shadow-sm space-y-6">
        <div class="flex items-center space-x-2">
            <div>
                <h3 class="text-sm font-semibold text-gray-900">Mulai Penanaman Bibit Baru</h3>
                <p class="text-xs text-gray-500">Membuka batch produksi baru</p>
            </div>
        </div>

        <form action="/production/usage/seed" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            
            <!-- Pilih Jenis Bibit -->
            <div>
                <label class="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1.5">Pilih Jenis Bibit</label>
                <select name="product_id" required
                    class="w-full text-sm bg-gray-50 border border-gray-200 rounded-lg px-3.5 py-2 text-gray-800 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition">
                    <?php $__currentLoopData = $seeds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($seed->id); ?>">
                            <?php echo e($seed->name); ?> (Tersedia: <?php echo e($seed->stock_available); ?> <?php echo e($seed->unit); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Tanggal Tanam Aktual -->
            <div>
                <label class="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1.5">Tanggal Tanam</label>
                <input type="date" name="usage_date" value="<?php echo e(date('Y-m-d')); ?>" required
                    class="w-full text-sm bg-gray-50 border border-gray-200 rounded-lg px-3.5 py-2 text-gray-800 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition">
            </div>

            <!-- Jumlah Bibit Ditanam -->
            <div>
                <label class="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1.5">Jumlah Bibit Ditanam (Kg)</label>
                <input type="number" name="quantity_used" required placeholder="Contoh: 50" min="1"
                    class="w-full text-sm bg-gray-50 border border-gray-200 rounded-lg px-3.5 py-2 text-gray-800 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition">
            </div>

            <!-- Submit Button -->
            <button type="submit" 
                class="w-full text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-lg py-2.5 transition shadow-sm mt-2">
                Konfirmasi & Mulai Tanam
            </button>
        </form>
    </div>

    <!-- Card 2: Pencatatan Pemakaian Pupuk Berkala -->
    <div class="bg-white border border-gray-200 rounded-lg p-6 shadow-sm space-y-6">
        <div class="flex items-center space-x-2">
            <div>
                <h3 class="text-sm font-semibold text-gray-900">Pencatatan Pemakaian Pupuk</h3>
                <p class="text-xs text-gray-500">Log pemakaian pupuk untuk batch berjalan</p>
            </div>
        </div>

        <form action="/production/usage/fertilizer" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            
            <!-- Pilih Alokasi Batch Tanam -->
            <div>
                <label class="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1.5">Alokasi Batch Tanam Aktif</label>
                <select name="production_schedule_id" required
                    class="w-full text-sm bg-gray-50 border border-gray-200 rounded-lg px-3.5 py-2 text-gray-800 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition">
                    <option value="">-- Pilih Batch Tanam Aktif --</option>
                    <?php $__currentLoopData = $activeSchedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sch->id); ?>">
                            Batch #<?php echo e($sch->id); ?> | Mulai: <?php echo e(date('d M Y', strtotime($sch->planting_start_date))); ?> | <?php echo e($sch->crop_season); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Pilih Jenis Pupuk -->
            <div>
                <label class="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1.5">Pilih Jenis Pupuk</label>
                <select name="product_id" required
                    class="w-full text-sm bg-gray-50 border border-gray-200 rounded-lg px-3.5 py-2 text-gray-800 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition">
                    <?php $__currentLoopData = $fertilizers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($fert->id); ?>">
                            <?php echo e($fert->name); ?> (Tersedia: <?php echo e($fert->stock_available); ?> <?php echo e($fert->unit); ?>)
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <!-- Tanggal Pemupukan -->
            <div>
                <label class="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1.5">Tanggal Pemupukan</label>
                <input type="date" name="usage_date" value="<?php echo e(date('Y-m-d')); ?>" required
                    class="w-full text-sm bg-gray-50 border border-gray-200 rounded-lg px-3.5 py-2 text-gray-800 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition">
            </div>

            <!-- Jumlah Pupuk Digunakan -->
            <div>
                <label class="block text-xs font-semibold text-gray-600 uppercase tracking-wider mb-1.5">Jumlah Pupuk Digunakan (Kg)</label>
                <input type="number" name="quantity_used" required placeholder="Contoh: 10" min="1"
                    class="w-full text-sm bg-gray-50 border border-gray-200 rounded-lg px-3.5 py-2 text-gray-800 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition">
            </div>

            <!-- Submit Button -->
            <button type="submit" 
                class="w-full text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg py-2.5 transition shadow-sm mt-2">
                Simpan Data Pemupukan
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\pertanian-indri-rancaoray-app\resources\views/production/usage.blade.php ENDPATH**/ ?>